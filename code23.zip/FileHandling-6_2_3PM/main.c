#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    int cnt =0;
    int i = 0;

    fp = fopen("file.txt", "r");

    if(fp == NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    //moves the file pointer to the end of the file
    fseek(fp, 0, SEEK_END);

    //get the pointer of the file pointer
    cnt = ftell(fp);

    printf("pointer position is: %d", cnt);

    while(i < cnt)
    {
        i++; // i = 0, 1
        fseek(fp, -i, SEEK_END);
        printf("%c", fgetc(fp));
    }

    printf("\n");
    fclose(fp);
    fp = NULL;

    return 0;
}
