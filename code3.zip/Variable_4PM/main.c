#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 45; //declaration and initialization
    int b; //declaration

    printf("a is: %d\n", a);

    a = 70;//re-initialization

    printf("a is: %d\n", a);

    a = 3;//again re-initialization

    printf("a is: %d\n", a);

    b = a;//initialization

    printf("b is: %d", b);

    return 0;
}
