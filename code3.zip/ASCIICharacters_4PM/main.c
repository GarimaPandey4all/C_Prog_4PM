#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch; //size: 1 byte

    printf("Enter any character:");
    scanf("%c", &ch);

    printf("Entered Character's decimal value is: %d", ch);

    /*
        A-Z : 65-90

        a-z : 97-122

    */

    return 0;
}
