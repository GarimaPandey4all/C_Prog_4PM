#include <stdio.h>
#include <stdlib.h>

/*
    (a + b) = Expression

    a , b = operands

    + = operator

*/


int main()
{
    int a, b;

    printf("Enter any value for a:");
    scanf("%d", &a);

    printf("Enter any value for b:");
    scanf("%d", &b);

    printf("Addition is: %d\n", (a+b));
    printf("Subtraction is: %d\n", (a-b));
    printf("Multiplication is: %d\n", (a*b));
    printf("Division is: %d\n", (a/b));

    // % - Modulus Operator - it gives remainder

    printf("Modulus is: %d\n", (a%b));

    // ++ - Increment Operator

    // Pre-Increment and Post Increment

    // a = 5, b = 7

    printf("Pre-Increment is: %d\n", (++a)); // a = 5 + 1 = 6

    printf("Post-Increment is: %d\n", (a++)); // a = 6

    printf("a is: %d\n", a); // a = 7

    // -- : Decrement Operator

    // Pre-Decrement and Post Decrement

    printf("Pre-Decrement is: %d\n", (--b)); // b = 7 - 1 = 6

    printf("Post-Decrement is: %d\n", (b--)); // b = 6

    printf("b is: %d\n", b); // b = 5

    return 0;
}
