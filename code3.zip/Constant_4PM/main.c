#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int a = 10; //const--> constant --> fixed the value

    //a = 20; // error

    printf("a is: %d", a);

    return 0;
}
