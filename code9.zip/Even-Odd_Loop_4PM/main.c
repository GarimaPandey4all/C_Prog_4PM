#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, i;

    for(i=1; i<=50; i++)
    {
        ((i % 2) == 0) ? printf("Number is Even: %d\n", i) : printf("Number is Odd: %d\n", i);
    }

    return 0;
}
