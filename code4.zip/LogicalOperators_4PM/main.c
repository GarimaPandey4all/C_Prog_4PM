#include <stdio.h>
#include <stdlib.h>

/*
    1. && - Logical AND Operator
    2. || - Logical OR Operator
    3. ! - Logical NOT Operator
            true = false
            false = true
*/

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Logical AND Operator:%d\n", (a && b));
    printf("Logical OR Operator:%d\n", (a || b));
    printf("Logical NOT Operator:%d\n", !(a && b));

    return 0;
}
