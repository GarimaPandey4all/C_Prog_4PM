#include <stdio.h>
#include <stdlib.h>

/*
    1. Swapping Numbers by using third variable
    2. Swapping Numbers without using third variable

*/

int main()
{
    //Swapping Numbers by using third variable

    int a, b, temp;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before Swapping the value of a=%d and b=%d\n\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("After Swapping the value of a=%d and b=%d\n\n", a, b);

    return 0;
}
