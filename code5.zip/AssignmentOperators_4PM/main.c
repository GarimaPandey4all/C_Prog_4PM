#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 0;

    sum += 50; //sum = sum + 50;

    printf("Sum is : %d", sum);

    return 0;
}
