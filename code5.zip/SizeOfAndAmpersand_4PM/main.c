#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 20;

    printf("Size of int: %d\n", sizeof(int));
    printf("Size of char: %d\n", sizeof(char));
    printf("Size of float: %d\n", sizeof(float));
    printf("Size of double: %d\n", sizeof(double));
    printf("Size of long double: %d\n", sizeof(long double));

    printf("address of a is: %d\n", &a);

    return 0;
}
