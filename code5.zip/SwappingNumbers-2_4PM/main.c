#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Swapping Numbers without using third variable

    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

//    printf("Before Swapping the value of a=%d and b=%d\n\n", a, b);
//
//    //First - Way: + and - // a = 5, b = 7
//
//    a = a + b; // a = 5 + 7 = 12
//    b = a - b; // b = 12 - 7 = 5
//    a = a - b; // a = 12 - 5 = 7
//
//    printf("After Swapping the value of a=%d and b=%d\n\n", a, b);

//    printf("Before Swapping the value of a=%d and b=%d\n\n", a, b);
//
//    //Second - Way: * and / // a = 5, b = 7
//
//    a = a * b; // a = 5 * 7 = 35
//    b = a / b; // b = 35 / 7 = 5
//    a = a / b; // a = 35 / 5 = 7
//
//    printf("After Swapping the value of a=%d and b=%d\n\n", a, b);

    printf("Before Swapping the value of a=%d and b=%d\n\n", a, b);

    //Third - Way: X-OR - ^ // a = 5, b = 7

    a = a ^ b; // a = 5 ^ 7 = 2
    b = a ^ b; // b = 2 ^ 7 = 5
    a = a ^ b; // a = 2 ^ 5 = 7

    printf("After Swapping the value of a=%d and b=%d\n\n", a, b);

    return 0;
}
