#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 45;
    float b = 45.78f;
    double d = 67.79;
    char ch = 'R';

    //Escape Character : \n - new line

    printf("a is: %d\n", a);
    printf("b is: %.2f\n", b);
    printf("d is: %.2lf\n", d);
    printf("ch is: %c\n", ch);

    return 0;
}
