#include <stdio.h>
#include <stdlib.h>

/*
    Function has four types:

    1. Function without arguments and function without return value.
    2. Function with arguments and function without return value.
    3. Function without arguments and function with return value.
    4. Function with arguments and function with return value.
*/

//1. Function without arguments and function without return value.

void Add(); //Function Declaration

int main() // int : return value
{
    Add(); //Function calling
    Add();
    Add();
    Add();

    return 0;
}

//Function Definition : without arguments and without return value
void Add()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));

}

