#include <stdio.h>
#include <stdlib.h>

//Function: Procedure/Particular Task : gives us reusability

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", (a + b));

    return 0;
}
/*
Add()
{
    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", (a + b));
}
*/
