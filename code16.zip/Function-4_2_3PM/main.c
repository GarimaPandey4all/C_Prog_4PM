#include <stdio.h>
#include <stdlib.h>

//4.Function with arguments and function with return value.

int Add(int , int);

int main()
{
    int x, y, result;

    result = Add(x, y);

    printf("Addition is: %d", result);

    return 0;
}

int Add(int a, int b)
{

    printf("Enter value for x and y:");
    scanf("%d %d", &a, &b);

    return (a + b);
}
