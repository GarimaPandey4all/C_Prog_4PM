#include <stdio.h>
#include <stdlib.h>

//2.Function with arguments and function without return value.

void Add(int, int);

int main()
{
    int x, y;

   // x, y: Function Arguments/ Actual Parameters
    Add(x , y);
    Add(x , y);

    return 0;
}

// a, b: Function Parameters / Formal Parameters
void Add(int a, int b) // Function Prototype
{
    printf("Enter value for x and y:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}
