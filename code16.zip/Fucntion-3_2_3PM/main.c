#include <stdio.h>
#include <stdlib.h>




int Add();

int main()
{
//    int result;
//
//    result = Add();
//
//    printf("Addition is: %d", result);

    Add();

    return 0;
}


int Add()
{
    int a, b;

    printf("Enter value for x and y:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));

    //return (a + b);

    return 0;
}
