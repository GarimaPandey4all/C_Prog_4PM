#include <stdio.h>
#include <stdlib.h>

int main()
{
     int n, r, reverse = 0;

    printf("Enter any number to check whether the number is palindrome or not:");
    scanf("%d", &n);

    while(n > 0)
    {
        r = n % 10; // n = 121 // r = 121 % 10 // r = 1, 2, 1
        reverse = reverse * 10 + r; // sum = 0 * 10 + 1 = 1, 1 * 10 + 2 = 12, 12 * 10 + 1 = 121
        n = n / 10; // n = 121 / 10 = 12, 1, 0
    }

    printf("Reverse Number is: %d", reverse);

    return 0;
}
