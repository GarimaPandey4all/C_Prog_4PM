#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for(i = 65; i <= 69; i++)
    {
        for(j = 65; j <= 69; j++)
        {
            //printf("%c", j);
            printf("%c", i);
        }
        printf("\n");
    }

    return 0;
}
