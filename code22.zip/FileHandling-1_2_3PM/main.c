#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    int c;

    fp = fopen("file.txt", "r");

    if(fp == NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    while((c = fgetc(fp)) != EOF) // end of file
    {
        printf("%c", c);
    }

    fclose(fp);
    fp = NULL;

    return 0;
}
