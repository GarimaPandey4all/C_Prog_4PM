#include <stdio.h>
#include <stdlib.h>

/*
    Dynamic Memory Allocation:

    2. Calloc(): Contiguous Allocation

    The malloc() function allocates memory and leaves the memory uninitialized.
    Whereas the calloc() function allocates memory and initializes all bits to zero.

    Syntax:

    ptr = (castType *)calloc(n, size);

*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    text=(char *)calloc(size, sizeof(char)); // char = 1 byte, size = 2= 3 bytes = 24 bits = zero

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    free(text);
    text = NULL;

    return 0;
}
