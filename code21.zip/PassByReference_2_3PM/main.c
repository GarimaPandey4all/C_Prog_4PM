#include <stdio.h>
#include <stdlib.h>

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Before Swapping the value of a=%d and b=%d\n", a, b);

    swap(&a, &b);

    printf("After Swapping the value of a=%d and b=%d\n", a, b);

    return 0;
}
