#include <stdio.h>
#include <stdlib.h>

/*
    Dynamic Memory Allocation:

    1. Malloc()

       malloc: Memory Allocation: The malloc() function reserves a block of memory of the
       specified number of bytes. And it returns a pointer of void which can be casted/conversion into
       pointers of any form.

       Syntax:

       ptr = (casttype *) malloc(size);

    2. Calloc()

*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    text=(char *)malloc(size * sizeof(char)); // char = 1 byte, size = 2= 3 bytes = 24 bits

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    free(text);
    text = NULL;

    return 0;
}
