#include <stdio.h>
#include <stdlib.h>

//Switch : Menu Driven Program


int main()
{
    int choice;
    int number;
    int a, b;

//    for(;;) // infinite loop
//    {
//
//    }
    while(1) // infinite loop //loop : if you want to repeat definite number of times
    {

    //Menu given
    printf("\n\nPress 1. Even - Odd\n");
    printf("Press 2. X-OR\n");
    printf("Press 3. Largest Number\n");
    printf("Press 4. Addition\n");
    printf("Press 5. Modulus\n");
    printf("Press 6. Exit\n");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter any number:");
        scanf("%d", &number);

        ((number % 2) == 0) ? printf("Number is Even") : printf("Number is Odd");
        break;

    case 2:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("X-OR is:%d", (a ^ b));
        break;

    case 3:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        (a > b) ? printf("A is Greater") : printf("B is Greater");
        break;

    case 4:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is:%d", (a + b));
        break;

    case 5:
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Modulus is:%d", (a % b));
        break;

    case 6:
        exit(0);

    default:
        printf("Invalid Choice");

    }
    }

    //printf("Outside Switch");

    return 0;
}
