#include <stdio.h>
#include <stdlib.h>

/*
    Three types of Loops:

    1. for loop

    int i;

    for(initialization; condition; increment/decrement)
    for(i = 1; i <= 10; i++)
    {
        //block of loop
    }

    2. while loop

    int i = 1; // initialization

    while(i <= 10) // condition
    {
        //block of loop
        increment/decrement
    }

    3. do-while loop

    int i = 1; // initialization

    do
    {
        //block of loop
        increment / decrement

    }while(i <= 10); // condition

*/



int main()
{
    int i;

    for(i = 1; i <= 20; i++)
    {
        printf("Hello World\n");
    }

    return 0;
}
