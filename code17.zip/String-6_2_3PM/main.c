#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[10];

    printf("Enter any string:");
    gets(str);

    printf("Lowercase String: %s\n", strlwr(str));

    printf("Uppercase String: %s\n", strupr(str));

    return 0;
}
