#include <stdio.h>
#include <stdlib.h>

/*
    strcmp(str1, str2) // str1 = a, str2 = b

    a > b = 1

    b < a = -1

    a == a = 0

*/

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter String 1:");
    gets(str1);

    printf("Enter String 2:");
    gets(str2);

    if(strcmp(str1, str2) == 0)
        printf("You entered the same strings");
    else
        printf("Not the same strings");

    return 0;
}
