#include <stdio.h>
#include <stdlib.h>

/*
    String Pre-Build Functions:

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Lowercase / Uppercase

*/

int main()
{
    char name[10];

    printf("Enter your name:");
    gets(name);

    printf("Your name's length is: %d", strlen(name));

    return 0;
}
