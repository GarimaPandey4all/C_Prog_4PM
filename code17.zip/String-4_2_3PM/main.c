#include <stdio.h>
#include <stdlib.h>

// "\0" - It indicates that string is terminate.

int main()
{
    char firstName[10];
    char lastName[10];

    printf("Enter your firstname:");
    gets(firstName);

    printf("Enter your lastname:");
    gets(lastName);

    printf("Your Fullname is: %s\n", strcat(firstName, lastName));

    return 0;
}
