#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//String: It is a collection of characters is called string.

// Character of arrays is called string in c.

int main()
{
    char name[10];

    printf("Enter your name:");
    //scanf("%s", &name);
    gets(name); // read string input

    //puts(name);
    printf("Your name is:%s", name);

    return 0;
}
