#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;

    int *pvalue = &value;

    int result = 0;

    result = *pvalue + 30;

    printf("Result is:%d\n", result);

    *pvalue += 10; // *pvalue = *pvalue + 10;

    printf("Value is: %d\n", value);

    return 0;
}
