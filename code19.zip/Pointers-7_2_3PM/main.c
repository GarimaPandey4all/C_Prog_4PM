#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Pointer to a constant // value can't be changed

    int value = 10;
    int number = 20;

    const int *pvalue = &value;

    //*pvalue = 100; // error

    pvalue = &number;

    printf("value is: %d\n", *pvalue);

    return 0;
}
