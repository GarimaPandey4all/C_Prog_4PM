#include <stdio.h>
#include <stdlib.h>

int main()
{
    long num1 = 0L;
    long num2 = 0L;

    long *pnum = NULL;

    pnum = &num1; // num1 = 0;
    *pnum = 2L; //num1 = 2;
    ++num2; // num2 = 1;
    num2 += *pnum; // num2 = 1 + 2 = 3;

    pnum = &num2; // num2 = 3
    ++*pnum; // num2 = 4

    printf("Num 1: %d\n", num1);
    printf("Num 2: %d\n", num2);
    printf("Pnum is: %d\n", *pnum);
    printf("Pnum + num2 is: %d\n", *pnum + num2);

    return 0;
}
