#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    int *pvalue = &value;

    //int *pvalue = NULL; // NULL - Empty

    //pvalue = &value;

    printf("Value is: %d\n", *pvalue);

    printf("Value is: %d\n", pvalue);

    printf("Value is: %d\n", &pvalue);

    return 0;
}
