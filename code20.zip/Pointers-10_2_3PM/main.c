#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    float j = 2.3f;
    char z = 'A';

    void *ptr; // void pointer

    ptr = &i;
    printf("I is: %d\n", *(int *)ptr);

    ptr = &j;
    printf("J is: %f\n", *(float *)ptr);

    ptr = &z;
    printf("Z is: %c\n", *(char *)ptr);

    return 0;
}
