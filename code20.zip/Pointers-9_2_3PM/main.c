#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int value = 10;
    int number = 20;

    //Pointer to a constant and constant pointer// Value and Address can't be changed

    const int *const pvalue = &value;

    //*pvalue = 30; // error

    //pvalue = &number; // error

    //value = 40; // error

    printf("Value is: %d", *pvalue);

    return 0;
}
