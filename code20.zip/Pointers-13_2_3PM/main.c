#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date1, *pdate;

//struct Date date1, date2, date3;

int main()
{
    //struct Date date1, date2, date3;

    pdate = &date1;

    pdate->Day = 6;
    pdate->Month = 10;
    (*pdate).Year = 2020;

    printf("Day = %d, Month = %d, and Year = %d", (*pdate).Day, pdate->Month, pdate->Year);

    return 0;
}
