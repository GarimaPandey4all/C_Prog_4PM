#include <stdio.h>
#include <stdlib.h>

union Date
{
    int Day;
    int Month;
    int Year;
}date1, *pdate;

//union Date date1, date2, date3;

int main()
{
    //union Date date1, date2, date3;
    pdate = &date1;

    pdate->Day = 6;

    printf("Day is: %d\n", pdate->Day);

    pdate->Month = 10;

    printf("Month is: %d\n", pdate->Month);

    pdate->Year = 2020;

    printf("Year is: %d\n", pdate->Year);

    return 0;
}
