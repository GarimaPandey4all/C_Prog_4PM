#include <stdio.h>
#include <stdlib.h>

union Date
{
    int Day;
    int Month;
    int Year;
}date1;

//union Date date1, date2, date3;

int main()
{
    //union Date date1, date2, date3;

    date1.Day = 6;

    printf("Day is: %d\n", date1.Day);

    date1.Month = 10;

    printf("Month is: %d\n", date1.Month);

    date1.Year = 2020;

    printf("Year is: %d\n", date1.Year);

    return 0;
}
