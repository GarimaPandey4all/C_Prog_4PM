#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int Day;
    int Month;
    int Year;
}date1;

//struct Date date1, date2, date3;

int main()
{
    //struct Date date1, date2, date3;

    date1.Day = 6;
    date1.Month = 10;
    date1.Year = 2020;

    printf("Day = %d, Month = %d, and Year = %d", date1.Day, date1.Month, date1.Year);

    return 0;
}
