#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[3] = {10, 20, 30};

    int *ptr[3];

    int i;

    for(i = 0; i < 3; i++)
    {
        ptr[i] = &arr[i]; // assign the address of array
    }

    for(i = 0; i < 3; i++)
    {
        printf("Values of Array are: %d\n", *ptr[i]);
    }

    return 0;
}
