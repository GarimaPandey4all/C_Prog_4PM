#include <stdio.h>
#include <stdlib.h>

//Enum: Enumeration: Group of Constants

int main()
{
    enum Week {Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today = Saturday;

    printf("Today is: %d", Today);

    return 0;
}
