#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    /*
        (Shorthand of If-Else)
        Ternary/Conditional Operator - ? :

        Ternary - 3

        (Condition) ? True : False;

        (Expression-1) ? Expression-2 : Expression-3
    */

    (a > b) ? printf("A is Greater") : printf("B is Greater");

    return 0;
}
