#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, largest;

    printf("Enter any value for a, b and c:");
    scanf("%d %d %d", &a, &b, &c);

    largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

    printf("Largest number is:%d", largest);

    return 0;
}
