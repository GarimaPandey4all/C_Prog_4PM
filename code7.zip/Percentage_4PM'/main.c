#include <stdio.h>
#include <stdlib.h>

int main()
{
    int hindi, english, maths, sanskrit, history;
    int percentage;

    printf("Enter your marks:");
    scanf("%d %d %d %d %d", &hindi, &english, &maths, &sanskrit, &history);

    percentage = (hindi + english + maths + sanskrit + history) / 5;

    printf("Percentage is:%d\n", percentage);

    /*
        50 to 60 : Grade D

        60 to 70 : Grade C

        70 to 80 : Grade B

        80 to 100 : Grade A

        Otherwise Fail...
    */

    if(percentage >= 50 && percentage <= 60)
        printf("Grade D");

    else if(percentage >= 60 && percentage <= 70)
        printf("Grade C");

    else if(percentage >= 70 && percentage <= 80)
        printf("Grade B");

    else if(percentage >= 80 && percentage <= 100)
        printf("Grade A");

    else
        printf("Otherwise Fail...");

    return 0;
}
