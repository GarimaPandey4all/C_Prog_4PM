#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    char _operator;

    printf("Enter any character:");
    scanf("%c", &_operator);

    switch(_operator)
    {
    case '+':
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Addition is:%d\n", (a + b));
        break;

    case '-':
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Subtraction is:%d\n", (a - b));
        break;

    case '*':
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Multiplication is:%d\n", (a * b));
        break;

    case '/':
        printf("Enter any value for a and b:");
        scanf("%d %d", &a, &b);
        printf("Division is:%d\n", (a / b));
        break;

    default:
        printf("Invalid choice\n");
    }

    //printf("Outside Switch");

    return 0;
}
