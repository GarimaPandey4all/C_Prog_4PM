#include <stdio.h>
#include <stdlib.h>

//Array : It is used to store multiple values in a single variable.
//Array : It is a collection of similar types of data.

int main()
{
    int arr[5] = {10, 20, 30, 40, 50}; // [] - square bracket / subscript operator // 5 - size of the array
    int i;

    /*
    printf("Array first value: %d\n", arr[0]);
    printf("Array second value: %d\n", arr[1]);
    printf("Array third value: %d\n", arr[2]);
    printf("Array fourth value: %d\n", arr[3]);
    printf("Array five value: %d\n", arr[4]);
    */

    printf("Values in an Array are:\n");
    for(i = 0; i<5; i++)
    {
        printf("%d\n", arr[i]);
    }

    return 0;
}
