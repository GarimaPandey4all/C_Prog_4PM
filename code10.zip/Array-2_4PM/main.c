#include <stdio.h>
#include <stdlib.h>

//Array - 1D Array

int main()
{
    int arr[5], i;

    printf("Enter any value in an Array:");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Values in an Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\n", arr[i]);
    }

    return 0;
}
