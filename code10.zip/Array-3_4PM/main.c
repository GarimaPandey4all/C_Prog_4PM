#include <stdio.h>
#include <stdlib.h>
#define MONTHS 12

//Macros : When you want to create your own pre-processor directive : value fixed

int main()
{
    int days[MONTHS] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 31, 30, 31};
    int i;

    for(i = 0; i < MONTHS; i++)
    {
        printf("%d Month has %d days.\n", i + 1, days[i]);
    }

    return 0;
}
