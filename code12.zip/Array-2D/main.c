#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int arr[5] = {10, 20, 30, 40, 50};

    // Array - 2D
    int array[2][3];

//    int array[2][3] = {{10, 20, 30},
//                       {40, 50, 60}};

    int i, j;

    printf("Enter values in an 2D-Array:");
    for(i = 0; i < 2; i++) // Nested Loops
    {
        for(j = 0; j < 3; j++)
        {
            scanf("%d", &array[i][j]);
        }
    }

    // 1D - 1 Loop , 2D - 2 Loops
    printf("Values in an Array are:\n");
    for(i = 0; i < 2; i++) // Nested Loops
    {
        for(j = 0; j < 3; j++)
        {
            printf("%d\t", array[i][j]);
        }
        printf("\n");
    }

    return 0;
}
