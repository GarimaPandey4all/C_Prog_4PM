#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix1[5][5], matrix2[5][5], result[5][5], i, j, rows, columns;

    printf("Please enter number of rows:");
    scanf("%d", &rows); // rows = 2

    printf("Please enter number of columns:");
    scanf("%d", &columns); // columns = 3

    printf("Enter %d values in Matrix - 1:\n", rows * columns);
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix1[i][j]);
        }
    }

    printf("Enter %d values in Matrix - 2:\n", rows * columns);
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix2[i][j]);
        }
    }

    printf("Matrix - 1:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix1[i][j]);
        }
        printf("\n");
    }

    printf("Matrix - 2:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix2[i][j]);
        }
        printf("\n");
    }


    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    printf("Addition of two matrices is:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}
